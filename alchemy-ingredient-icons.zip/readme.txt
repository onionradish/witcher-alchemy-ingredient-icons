==========================================================================
Witcher Ingredient Icons
v 1.0

Author: onionradish [AT] bitlet.com
==========================================================================
DESCRIPTION 

This mod simplifies alchemy ingredient inventory management and potion-
mixing by updating the inventory icons for alchemy ingredients. Inventory
icons better show each ingredient's primary and secondary components
(if any), without needing to mouse-over the ingredient. 


==========================================================================
INSTALLATION
==========================================================================
Copy the extracted "Override" folder into the "Data" folder
of your The Witcher install folder.

==========================================================================
UNINSTALLING
==========================================================================
Delete the "iit_ingr_*.dds" files from the "Data\Override"
folder in your The Witcher install folder.
	
==========================================================================
COPYRIGHT
==========================================================================
This mod may be included with any other mod, provided that credit for 
the mod is given and no fee is charged for the mod or distribution. 
Please email the author if you've incorporated the mod. 


CHANGELOG
==========================================================================
v1.00	Initial release

Please report any bugs to the author. 